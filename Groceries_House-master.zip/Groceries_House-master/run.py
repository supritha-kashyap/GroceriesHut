from groceries import app
import os

os.environ['ROOT_PATH'] = os.path.dirname(os.path.abspath(__file__))

if __name__ == "__main__":
    app.run(debug=True)
