#!/usr/bin/bash


help(){
    echo "Usage"
    echo "--backup  : dump file from database to file"
    echo "--recover : recover database from file"
}

if [ $# -eq 1 ]
then

    if [ $1 == "--backup" ]
    then
        mysqldump -u $db_username -p grocerymane --single-transaction --quick --lock-tables=false > database/db-backup.sql
    elif [ $1 == "--recover" ]
    then
        mysql -u $db_username -p grocerymane < database/db-backup.sql
    else
        help
    fi
else
    help    
fi
