from flask_sqlalchemy import SQLAlchemy
# from groceries.items.models import db, migrate
from groceries.auth.models import User
from groceries import db
from groceries.items.models import Item



# db = SQLAlchemy()

class Cart(db.Model):
    __tablename__ = 'Cart'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey(
        'User.id', ondelete="CASCADE"))
    item_id = db.Column(db.Integer, db.ForeignKey(
        'Item.id', ondelete="CASCADE"))
    item = db.relationship('Item', cascade="all,delete",
                            backref=db.backref('carts', lazy='dynamic'),uselist=False)
    item_quantity = db.Column(db.Integer)

    def __init__(self, user_id, item_id, item_quantity):
        self.user_id = user_id
        self.item_id = item_id
        self.item_quantity = item_quantity
        self.item = Item.query.filter_by(id=item_id).first()
