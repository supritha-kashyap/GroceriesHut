from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from groceries import app, login_manager
from itsdangerous import URLSafeTimedSerializer, SignatureExpired
from groceries.auth.models import User
from groceries.items.models import Item
from .models import Cart
from groceries.cart.models import db

cart_bp = Blueprint('cart_bp', __name__)
link_signature = URLSafeTimedSerializer(app.config['SECRET_KEY'])


@cart_bp.route('/', methods=['GET', 'POST'])
@login_required
def cart():
    cart_item = Cart.query.filter_by(user_id=current_user.get_id()).all()
    print(cart_item)
    return render_template('cart/cart.html', cart_item=cart_item)


@cart_bp.route('/add_to_cart', methods=['POST', 'GET'])
@login_required
def add_to_cart():
    if request.method == 'POST':
        item_id = request.form['item_id']
        number_of_item = request.form['number_of_items']
        user_id = current_user.get_id()
        item = Item.query.filter_by(id = item_id)
        user_cart = Cart.query.filter_by(user_id = user_id, item_id = item_id).first()
        if user_cart:
            user_cart.item_quantity += int(number_of_item)
            print(number_of_item)
        else:
            user_cart = Cart(user_id, item_id, number_of_item)
            db.session.add(user_cart)
        db.session.commit()
        return jsonify({"success": "done"})
    return "oops"


@cart_bp.route('/get_item_info', methods=['GET', 'POST'])
def get_item_info():
    if request.method == 'POST':
        item_dict = {}
        print(request.form['id'])
        item = Item.query.filter_by(id=request.form['id'])
        for i in item:
            item_dict['id'] = i.id
            item_dict['cost'] = i.revised_cost
        return jsonify({"item": item_dict})
    return jsonify({'message': 'get'})


@cart_bp.route('/delete_cart_item', methods=['GET', 'POST'])
def delete_cart_item():
    if request.method == 'POST':
        try:
            item = Cart.query.filter_by(item_id=request.form['id']).first()
            db.session.delete(item)
            db.session.commit()
            return jsonify({"status": "deleted"})
        except Exception:
            return jsonify({"status": "Some internal error"})
    return jsonify({"return": "item"})
