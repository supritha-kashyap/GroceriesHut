from flask import Blueprint,render_template
from flask_login import login_required
from groceries import app
from itsdangerous import URLSafeTimedSerializer, SignatureExpired

booking_bp = Blueprint('booking_bp', __name__)
link_signature = URLSafeTimedSerializer(app.config['SECRET_KEY'])

@booking_bp.route('/', methods=['GET','POST'])
@login_required
def booking():
    return "Welcome to bookings"
