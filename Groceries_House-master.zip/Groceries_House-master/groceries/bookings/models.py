# from groceries.cart.models import db,migrate
from flask_sqlalchemy import SQLAlchemy
from groceries.auth.models import User
from groceries.items.models import Item
from groceries import db


# db = SQLAlchemy()


allbooking = db.Table('allbooking',
                      db.Column('booking_id', db.Integer,
                                db.ForeignKey('Booking.id')),
                      db.Column('item_id', db.Integer,
                                db.ForeignKey('Item.id'))
                      )


class Booking(db.Model):
    __tablename__ = 'Booking'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('User.id'))
    items = db.relationship('Item', secondary=allbooking, cascade="all,delete",
                            backref=db.backref('bookings', lazy='dynamic'))
    booking_date = db.Column(db.DateTime)
    booking_feedback_stars = db.Column(db.Integer, nullable=True)
    booking_feedback_sentence = db.Column(db.Text, nullable=True)

    def __init__(self, user_id, items, booking_date):
        self.user_id = user_id
        self.items = items
        self.booking_date = booking_date
