from groceries import app
from groceries import mail
from groceries.auth.models import db
from groceries.auth.models import User
from groceries.auth.forms import Registration, LoginForm
from flask_mail import Message
from itsdangerous import URLSafeTimedSerializer, SignatureExpired
from flask_login import login_user, logout_user, login_required
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort

auth_bp = Blueprint('auth_bp', __name__)
link_signature = URLSafeTimedSerializer(app.config['SECRET_KEY'])


@auth_bp.route('/', methods=['POST', 'GET'])
def signin():
    form = LoginForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            user = User.query.filter_by(email=form.email.data).first()
            if user:
                if user.check_password(form.password.data):
                    if user.email_confirmed:
                        login_user(user)
                        next = request.args.get('next')
                        return redirect(next or url_for("product_bp.dashboard"))
                    else:
                        flash("Activate your account before Sigin")
                        return redirect(url_for('auth_bp.signin'))
                else:
                    flash("Incorrect password")
                    return redirect(url_for('auth_bp.signin'))
            else:
                flash("User doesn't exist, please register")
                return redirect(url_for('auth_bp.signin'))
    return render_template('login.html', form=form)


@auth_bp.route('/forgot_password')
def forgot_password():
    return "password"


@auth_bp.route('/signup', methods=['POST', 'GET'])
def signup():
    form = Registration()
    if request.method == 'POST':
        if form.validate_on_submit():
            new_user = User(
                email=form.email.data,
                f_name=form.f_name.data,
                l_name=form.l_name.data,
                phno=form.phno.data,
                password=form.password.data,
                gender=form.gender.data,
                date_of_birth=form.date_of_birth.data
            )
            token = link_signature.dumps(form.email.data, salt='email-confirm')
            msg = Message("Confirm Email", sender=app.config['MAIL_USERNAME'],
                          recipients=[form.email.data])
            link = url_for('auth_bp.confirm_email',
                           token=token, _external=True)
            msg.body = f'Your Email confirmation link is {link}'
            try:
                db.session.add(new_user)
                db.session.commit()
                mail.send(msg)
                flash("Verification link sent to your mail")
            except Exception:
                return render_template("signup.html", form=form)
            return redirect(url_for('auth_bp.signin'))
    return render_template('signup.html', form=form)


@auth_bp.route('/signout')
@login_required
def signout():
    logout_user()
    return redirect(url_for("product_bp.dashboard"))


@auth_bp.route('/confirm_email/<token>')
def confirm_email(token):
    try:
        email = link_signature.loads(token, salt='email-confirm', max_age=600)
        user = User.query.filter_by(email=email).first()
        if user:
            user.email_confirmed = True
            db.session.commit()
    except SignatureExpired:
        flash("Link is expired")
        flash("Fresh link is sent to the same email")
        email = link_signature.loads(token, salt='email-confirm')
        new_token = link_signature.dumps(email, salt='email-confirm')
        msg = Message("Confirm Email", sender=app.config['MAIL_USERNAME'],
                      recipients=[email])
        link = url_for('auth_bp.confirm_email',
                       token=new_token, _external=True)
        msg.body = f'Your Email confirmation link is {link}'
        mail.send(msg)
        return redirect(url_for('auth_bp.signin'))
    flash("Account Activated")
    return redirect(url_for('auth_bp.signin'))
