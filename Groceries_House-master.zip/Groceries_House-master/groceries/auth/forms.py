from flask_wtf import FlaskForm
from wtforms import form, StringField, PasswordField, SubmitField
from wtforms import RadioField, DateField
from wtforms.validators import InputRequired, Email, length, EqualTo


class Registration(FlaskForm):
    f_name = StringField(
        "First Name", [InputRequired("Please enter your first name")])

    l_name = StringField(
        "Last Name")

    email = StringField("Email", [InputRequired(
        "Please enter your email"), Email("Enter valid email")])

    phno = StringField(
        "Phone number", [InputRequired("Please enter your phone name")])

    gender = RadioField('Gender', choices=[('M', 'Male'), ('F', 'Female')])

    date_of_birth = DateField(
        "DOB (dd-mm-yyyy)", [InputRequired("Please enter your date of birth")],
        format='%d-%m-%Y')

    password = PasswordField("Password", validators=[length(min=8, max=16)])

    re_password = PasswordField(
        "Re-enter Password",
        validators=[length(min=8, max=16), EqualTo('password')])

    submit = SubmitField("Submit")


class LoginForm(FlaskForm):
    email = StringField(
        "Enter email", [InputRequired("Enter your email"), Email()])
    password = PasswordField("Enter you password", [
                             InputRequired("Please enter your password")])
    submit = SubmitField("Login")


class ForgotPassword(FlaskForm):
    email = StringField(
        "Enter Email", [InputRequired("Enter your email"), Email()])
    submit = SubmitField("Submit")


class PasswdRest(FlaskForm):
    password = PasswordField("New Password", validators=[
                             length(min=8, max=16)])
    re_password = PasswordField(
        "Re-enter New Password",
        validators=[length(min=8, max=16), EqualTo('password')])
    submit = SubmitField("Submit")
