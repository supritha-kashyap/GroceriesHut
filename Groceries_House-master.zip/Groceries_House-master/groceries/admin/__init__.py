import os
import groceries
from groceries import app
from groceries.bookings.models import db
from flask_mail import Message
from itsdangerous import URLSafeTimedSerializer, SignatureExpired
from flask_login import login_user, logout_user, login_required, current_user
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_admin import Admin, AdminIndexView, expose, form
from flask_admin.contrib.sqla import ModelView
from flask_admin.contrib import sqla
from groceries.auth.forms import LoginForm
from jinja2 import Markup
from groceries.auth.models import User


file_path = os.path.join(
    os.path.dirname(groceries.__file__),
    "static",
    "items",
    "images"
)


class GroceryAdminView(ModelView):
    def is_accessible(self):
        return current_user.is_authenticated and current_user.is_admin

    def inaccessible_callback(self, name, **kwargs):
        return redirect(url_for('auth_bp.signin', next=request.url))


class HomeView(AdminIndexView):
    @expose("/signin", methods=['POST', 'GET'])
    def signin(self):
        form = LoginForm()
        if request.method == 'POST':
            if form.validate_on_submit():
                user = User.query.filter_by(email=form.email.data).first()
                if user:
                    if user.check_password(form.password.data):
                        if user.is_admin:
                            login_user(user)
                            # return render_template("dashboard.html")
                            return redirect(url_for("admin.index"))
                        else:
                            flash("You are not admin")
                            return redirect(url_for('admin.signin'))
                    else:
                        flash("Incorrect password")
                        return redirect(url_for('admin.signin'))
                else:
                    flash("User doesn't exist, please register")
                    return redirect(url_for('admin.signin'))
        return self.render('login.html', form=form)

    def signin(self):
        form = LoginForm()
        if request.method == 'POST':
            if form.validate_on_submit():
                user = User.query.filter_by(email=form.email.data).first()
                if user:
                    if user.check_password(form.password.data):
                        if user.is_admin:
                            login_user(user)
                            # return render_template("dashboard.html")
                            return redirect(url_for("admin.index"))
                        else:
                            flash("You are not admin")
                            return redirect(url_for('admin.signin'))
                    else:
                        flash("Incorrect password")
                        return redirect(url_for('admin.signin'))
                else:
                    flash("User doesn't exist, please register")
                    return redirect(url_for('admin.signin'))
        return self.render('login.html', form=form)

    @expose('/')
    @login_required
    def index(self):
        if current_user.is_admin:
            return self.render("admin/index.html")
        else:
            return redirect(url_for('product_bp.dashboard'))

    @expose('/signout')
    @login_required
    def signout(self):
        logout_user()
        return redirect(url_for("product_bp.dashboard"))


class ItemView(sqla.ModelView):
    def _list_thumbnail(view, context, model, name):
        if not model.item_image:
            return ''
        return Markup('<img src="%s">' % url_for(
            'static',
            filename="items/images/" + form.thumbgen_filename(model.item_image)))

    column_formatters = {
        'item_image': _list_thumbnail
    }

    form_extra_fields = {
        'item_image': form.ImageUploadField('Image',
                                            base_path=file_path,
                                            thumbnail_size=(100, 100, True)),
    }
    form_choices = {
        'cost_type': [
            ('Kg', 'Kg'),
            ('Ltr', 'Ltr'),
            ('Single', 'Single'),
        ],
        'item_type': [
            ('freshvegetable', 'Fresh vegetable'),
            ('freshfruits', 'Fruits'),
            ('leaf', 'Leaf'),
            ('kit', 'Kit'),
        ]
    }
