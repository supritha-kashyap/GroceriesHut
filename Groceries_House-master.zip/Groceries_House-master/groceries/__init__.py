import os
from flask import Flask
from flask_mail import Mail
from flask_login import LoginManager
# from groceries.decorators import admin_required
from flask_migrate import Migrate
from flask_admin import Admin
from flask_admin.menu import MenuLink
from flask_sqlalchemy import SQLAlchemy


db_uri = f"mysql+pymysql://{os.environ['db_username']}:\
{os.environ['db_password']}@localhost/grocerymane"

# basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SECRET_KEY'] = '5369f133d9c5021c0edb9da0d19a40fd'
app.config['FLASK_ADMIN_SWATCH'] = 'cerulean'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USE_SSL'] = True
app.config['MAIL_USERNAME'] = os.environ['mail']
app.config['MAIL_PASSWORD'] = os.environ['password']


login_manager = LoginManager(app)
mail = Mail(app)

db = SQLAlchemy()
migrate = Migrate()

from groceries.auth import auth_bp
from groceries.items import product_bp
from groceries.cart import cart_bp
from groceries.bookings import booking_bp
from groceries.admin import GroceryAdminView, HomeView, ItemView
from groceries.auth.models import User
from groceries.items.models import Item
from groceries.cart.models import Cart
from groceries.bookings.models import allbooking, Booking


db.init_app(app)
migrate.init_app(app, db)


@app.route('/service-worker.js')
def serviceWorder():
    return app.send_static_file('service-worker.js')


admin = Admin(app, "GroceryMane-Admin",
              index_view=HomeView(), template_mode="bootstrap3")
admin.add_view(GroceryAdminView(User, db.session))
admin.add_view(ItemView(Item, db.session))
admin.add_link(MenuLink(name="Signout", url="/admin/signout"))

app.register_blueprint(auth_bp, url_prefix='/user')
app.register_blueprint(product_bp, url_prefix='/')
app.register_blueprint(cart_bp, url_prefix='/cart')
app.register_blueprint(booking_bp, url_prefix='/booking')


@login_manager.user_loader
def load_user(user_id):
    if User.query.get(user_id):
        print("this is user ", user_id)
        return User.query.get(user_id)
    return None
