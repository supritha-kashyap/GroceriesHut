# from flask_login import current_user
# # from groceries.auth.models import User
# from groceries.admin.models import Admin
# from flask import redirect, url_for
# from functools import wraps
#
#
# def admin_required(func):
#     @wraps(func)
#     def wrapper_func(*args, **kwargs):
#         try:
#             c = current_user.username
#             print(current_user, 'from decorator', c)
#             return func(*args, **kwargs)
#         except Exception:
#             if current_user.is_authenticated:
#                 return "<h1>Unauthorized</h1>You are not Authorized to\
#                             view this page.</h1>"
#             return redirect(url_for('admin_bp.signin'))
#     return wrapper_func
