from flask_wtf import FlaskForm
from flask_wtf.file import FileField,FileAllowed
from wtforms import StringField, IntegerField, SubmitField, FloatField, ValidationError, SelectField
from groceries.items.models import Item
from wtforms.validators import InputRequired, Email, length, EqualTo
choices = [ ('freshvegetable','Fresh Vegetable'),
            ('leaf','Leaf'),
            ('citricvegetable','Citric Vegetable'),
            ('freshfruits','Fresh Fruits'),
            ('nonveg','Non-Veg'),
            ('kit','Kit'),
            ]

class ItemForm(FlaskForm):
    name = StringField('Item Name',validators = [InputRequired()])
    image = FileField('Item Image',validators = [FileAllowed(['jpg','png','jpeg'])])
    cost = FloatField('Cost',validators = [InputRequired()])
    offer = FloatField('Offer Percentage',validators = [InputRequired()])
    cost_type = SelectField('Cost Type', choices=[('liter','/Liter'),('kg','/KG'),('single','/Single')])
    item_stock = IntegerField('Item Stock',validators = [InputRequired()])
    item_type = SelectField('Item Type', choices=choices)
    submit = SubmitField('Add Item')

    def check_item(self):
        if Item.query.filter_by(name = self.name.data).first():
            raise ValidationError('Item already exists')

    def check_offer(self):
        if self.offer.data > 100:
            raise ValidationError('Offer cannot be more than 100 percent')
