# from groceries.admin.models import db,migrate
from flask_sqlalchemy import SQLAlchemy
from groceries import db


# db = SQLAlchemy()


class Item(db.Model):
    __tablename__ = 'Item'
    id = db.Column(db.Integer, primary_key=True)
    item_image = db.Column(db.String(64), nullable=True)
    name = db.Column(db.String(32), unique=True, index=True)
    original_cost = db.Column(db.Float)
    revised_cost = db.Column(db.Float)
    offer_percentage = db.Column(db.Float)
    cost_type = db.Column(db.String(16))
    item_stock = db.Column(db.Integer)
    item_sold = db.Column(db.Integer)
    item_booked = db.Column(db.Integer)
    item_type = db.Column(db.String(32), nullable=True)

    def __init__(self, name, original_cost, offer_percentage, item_image, item_stock, cost_type, item_type):
        self.name = name
        self.item_image = item_image
        self.original_cost = original_cost
        self.offer_percentage = offer_percentage
        self.revised_cost = self.calculate_revised_cost()
        self.item_stock = item_stock
        self.item_sold = 0
        self.item_booked = 0
        self.cost_type = cost_type
        self.item_type = item_type

    def calculate_revised_cost(self):
        return self.original_cost - ((self.offer_percentage/100) * self.original_cost)

    def change_cost(self, cost):
        self.original_cost = cost
        self.revised_cost = self.calculate_revised_cost()

    def change_offer_percentage(self, offer_percentage):
        self.offer_percentage = offer_percentage
        self.revised_cost = self.calculate_revised_cost()

    def json(self):
        return {
            'id': self.id,
            'name': self.name,
            'original_cost': self.original_cost,
            'revised_cost': self.revised_cost,
            'offer_percentage': self.offer_percentage,
        }

class Combo(db.Model):
    __tablename__ = 'Combo'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64))
    item_id = db.Column(db.Integer, db.ForeignKey(
        'Item.id', ondelete="CASCADE"))
    item = db.relationship('Item', cascade="all,delete",
                            backref=db.backref('combo', lazy='dynamic'),uselist=False)
    quantity = db.Column(db.Integer)

    def __init__(self,name,item_id,quantity):
        self.name = name
        self.item_id = item_id
        self.item_quantity = item_quantity
        self.item = Item.query.filter_by(id=item_id).first()
