from flask import Blueprint, render_template
from flask_login import login_required
from groceries.items.models import Item
from groceries.items.models import db
from groceries.items.forms import ItemForm
import secrets
import os
from flask import redirect, url_for, request, jsonify
from PIL import Image

product_bp = Blueprint(
    'product_bp', __name__)


@product_bp.route('/')
# @login_required
def dashboard():
    return render_template('dashboard.html')


@product_bp.route('/product/<type>')
# @login_required
def product(type=None):
    items = Item.query.filter_by(item_type=type).all()
    print(items)
    return render_template('product.html', items=items, type = type)


@product_bp.route('/added_item')
def done():
    return render_template('/items/done.html')


def save_picture(form_picture, name):
    file_name = name + secrets.token_hex(16)
    _, ext = os.path.splitext(form_picture.filename)
    file_name = file_name + ext
    file_path = os.path.join(os.getenv('ROOT_PATH'),
                             'groceries/static/items/images', file_name)
    print(file_path)
    output_size = (300, 200)
    output_image = Image.open(form_picture)
    output_image = output_image.resize(output_size)
    output_image.save(file_path)
    return file_name


@product_bp.route('/additem/', methods=['GET', 'POST'])
def add_item():
    form = ItemForm()

    if form.validate_on_submit():
        if form.check_item():
            return
        if form.check_offer():
            return
        if form.image.data:
            image_file = save_picture(form.image.data, form.name.data)

        item = Item(
            name=form.name.data,
            original_cost=form.cost.data,
            offer_percentage=form.offer.data,
            item_image=image_file,
            item_stock=form.item_stock.data,
            cost_type=form.cost_type.data,
            item_type=form.item_type.data,
        )
        db.session.add(item)
        db.session.commit()
        db.session.refresh(item)
        return redirect(url_for('product_bp.done'))
    return render_template('/items/add_item.html', form=form)
