$(document).ready(function () {
    $(".cart_button").on('click', function () {
        item_id = this.id;
        number_of_items = $("#" + item_id + "qtty_value").val();
        var cart_item = {
            data: {
                item_id: item_id,
                number_of_items: number_of_items,
            },
            type: 'POST',
            url: '/cart/add_to_cart',
        };
        $.ajax(cart_item).done(function (data) {
            if (data.success) {
                alert("sucess");
            }
            else {
                alert("Something went wrong");
            }
        })
    })
})



$(document).ready(function () {
    var cart_item_list = {}
    $(".product").on('click', function () {
        var id = $(this).attr('id');
        var base_quantity = parseInt($('#' + id + "_value").val())
        $('#' + id + '_increment').on('click', function () {
            base_quantity = base_quantity + 1;
            $('#' + id + "_value").val(base_quantity);
        });
        $('#' + id + '_decrement').on('click', function () {
            base_quantity = base_quantity - 1;
            $('#' + id + "_value").val(base_quantity);

        });

        if (base_quantity < 1) {
            base_quantity = 1;
            $('#' + id + "_value").val(base_quantity);
            alert("Min Quantity should be 1");
        }

        cart_item_list[id] = {
            qty: base_quantity,
        };
        get_price_value(id);
    })

    function update_price_value(id, base_price) {
        var updated_price = 0;
        var qty = cart_item_list[id]['qty'];
        updated_price = base_price * qty;
        $('#' + id + '_total_price').text("Rs. " + updated_price);
    }

    function get_price_value(id) {
        var information = {
            data: {
                id: id,
            },
            type: 'POST',
            url: 'get_item_info',
        }
        $.ajax(information).done(function (data) {
            if (data.item) {
                // cart_item_list[id]['base_price'] = data['item']['cost'];
                var base_price = data['item']['cost'];
                update_price_value(id, base_price);
            }
        })
    }

    $(".remove_btn").on('click', function () {
        // alert($(this).parent().parent().attr('id'));
        var parent_id = $(this).parent().parent().attr('id');
        $(this).parent().parent('tr').remove();   
        delete cart_item_list[parent_id];

        var information = {
            data: {
                id: parent_id,
            },
            type: 'POST',
            url: 'delete_cart_item',
        };
        $.ajax(information).done(function (data) {
            if (data.status) {
                console.log(data.status);
            }
        })
    })
})